<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class UserModels extends CI_Model {

    public function get_users($data = []) {
        $this->db->where('inactive', 0);
        if (!empty($data)) {
            $this->db->where($data); // Apply condition
        }
        return $this->db->get('users')->result_array();
    }
    public function get_user($id) {
        return $this->db->get_where('users', ['id' => $id])->row();
    }

    public function insert_user($data) {
        // Perform insert
        $inserted = $this->db->insert('users', $data);

        // If successful, return inserted ID and user data
        if ($inserted) {
            $user_id = $this->db->insert_id();

            // Fetch the full user details just inserted
            $user = $this->db->get_where('users', ['id' => $user_id])->row_array();

            return [
                'status' => true,
                'user_id' => $user_id,
                'user' => $user
            ];
        } else {
            return [
                'status' => false,
                'error' => $this->db->error()
            ];
        }
    }
    public function update_user($id, $data) {
        return $this->db->where('id', $id)->update('users', $data);
    }

    public function delete_user($id) {
        return $this->db->delete('users', ['id' => $id]);
    }

    public function get_approval_person(){
        return $this->db->get('loan_approval_person')->result_array();
    }

    public function insert_loan($data){
        // echo "<pre>";print_r($data);
         return $this->db->insert('loans', $data);
    }

   
    public function get_loan_details($user_id="") {
        $this->db->select('loans.*, users.name, users.email, users.phone');
        $this->db->from('loans');
        $this->db->join('users', 'users.id = loans.user_id', 'left');
        $this->db->where('loans.inactive', 0);
        if (!empty($user_id)) {
            $this->db->where('loans.user_id', $user_id);
        }else{
            $this->db->where('loans.status' ,0);

        }
        $query = $this->db->get();

        // echo "<pre>SQL QUERY: " . $this->db->last_query() . "</pre>";

        return $query->result_array();
    }
    public function update_loan($id, $data) {
        // echo "iddd".$id."<pre>";print_r($data);exit;
        return $this->db->where('id', $id)->update('loans', $data);
    }
}
?>
