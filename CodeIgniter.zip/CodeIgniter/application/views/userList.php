<?php include_once("Admin/header.php"); ?>

<div class="container py-4">
  <div class="card shadow-sm border-0 rounded-4">
    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
      <h4 class="mb-0">User List</h4>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle">
          <thead class="table-light">
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Email</th>
              <th>Phone</th>
            </tr>
          </thead>
          <tbody>
            <?php if (!empty($sum)): ?>
              <?php foreach ($sum as $value): ?>
                <tr>
                  <td><?php echo $value["id"]; ?></td>
                  <td><?php echo htmlspecialchars($value["name"]); ?></td>
                  <td><?php echo htmlspecialchars($value["email"]); ?></td>
                  <td><?php echo htmlspecialchars($value["phone"]); ?></td>
                </tr>
              <?php endforeach; ?>
            <?php else: ?>
              <tr>
                <td colspan="4" class="text-center text-muted">No users found.</td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<?php include_once("Admin/footer.php"); ?>
