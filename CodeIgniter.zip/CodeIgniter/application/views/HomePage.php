<h1>Welcome to first project</h1>
<?php echo $name; ?>