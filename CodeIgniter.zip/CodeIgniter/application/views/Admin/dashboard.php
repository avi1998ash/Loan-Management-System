<?php include_once("header.php"); ?>
<h2 align="center">Welcome To Loan Management System</h2>
<?php include_once("footer.php"); ?>