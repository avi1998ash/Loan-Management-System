<?php 
    class Admin extends CI_Controller {
        public function login(){
            $this->load->view('Admin/login');
        }
        public function dashboard(){
            $this->load->view('Admin/dashboard');

        }
        public function LoanForm(){
            $this->load->view('Admin/LoanForm');

        }
        public function signup(){
            $this->load->view('Admin/signup');

        }
    }
?>