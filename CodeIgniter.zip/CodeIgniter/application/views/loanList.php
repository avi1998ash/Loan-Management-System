<?php include_once("Admin/header.php"); ?>
<div class="container py-4">
  <div class="card shadow-sm border-0 rounded-4">
    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
      <h4 class="mb-0">Loan Approval List</h4>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle">
          <thead class="table-light">
            <tr>
              <th scope="col">Sr. No</th>
              <th scope="col">Name</th>
              <th scope="col">Email</th>
              <th scope="col">Phone</th>
              <th scope="col">Amount</th>
              <th scope="col">Tenure (Months)</th>
              <th scope="col">Purpose</th>
              <th scope="col">Status / Action</th>
            </tr>
          </thead>
          <tbody>
            <?php $i = 0; foreach ($my_approvals as $value): ?>
              <tr>
                <td><?php echo ++$i; ?></td>
                <td><?php echo htmlspecialchars($value["name"]); ?></td>
                <td><?php echo htmlspecialchars($value["email"]); ?></td>
                <td><?php echo htmlspecialchars($value["phone"]); ?></td>
                <td>₹<?php echo number_format($value["amount"], 2); ?></td>
                <td><?php echo $value["tenure_months"]; ?></td>
                <td><?php echo nl2br(htmlspecialchars($value["purpose"])); ?></td>
                <td>
                  <?php if ($_SESSION['user']["UserType"] == 1): ?>
                    <div class="d-flex gap-2">
                      <a class="btn btn-sm btn-success" href="<?php echo base_url('index.php/UserController/approve?id=' . $value["id"] . '&level=' . $value["approval_level"]); ?>" onclick="return confirm('Approve this loan?')">
                        Approve
                      </a>
                      <a class="btn btn-sm btn-danger" href="<?php echo base_url('index.php/UserController/reject?id=' . $value["id"] . '&level=' . $value["approval_level"]); ?>" onclick="return confirm('Reject this loan?')">
                        Reject
                      </a>
                    </div>
                  <?php else: ?>
                    <?php if ($value['status'] == 1): ?>
                      <span class="badge bg-success">Approved</span>
                    <?php elseif ($value['status'] == 2): ?>
                      <span class="badge bg-danger">Rejected</span>
                    <?php else: ?>
                      <span class="badge bg-warning text-dark">Pending</span>
                    <?php endif; ?>
                  <?php endif; ?>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
        <?php if (empty($my_approvals)): ?>
          <div class="text-center text-muted py-3">
            No records found.
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>
<?php include_once("Admin/footer.php"); ?>
