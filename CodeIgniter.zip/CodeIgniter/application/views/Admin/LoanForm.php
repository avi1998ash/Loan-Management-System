<?php include_once("header.php"); ?>
<div class="container py-5">
  <div class="row justify-content-center">
    <div class="col-md-8 col-lg-6">
      <div class="card border-0 shadow-lg rounded-4">
        <div class="card-body p-5">
          <h2 class="text-center text-primary fw-bold mb-4">Apply for a Loan</h2>

          <form action="<?php echo base_url('index.php/UserController/LoanApply'); ?>" method="POST" novalidate>

            <!-- Loan Amount -->
            <div class="form-floating mb-3">
              <input type="number" class="form-control" id="amount" name="amount" placeholder="Loan Amount" required min="1000" step="100" oninput="calculateEMI()">
              <label for="amount">Loan Amount (INR)</label>
            </div>

            <!-- Loan Tenure -->
            <div class="form-floating mb-3">
              <select class="form-select" id="tenure" name="tenure" required onchange="calculateEMI()">
                <option value="" disabled selected>Select Tenure</option>
                <option value="6">6 Months</option>
                <option value="12">12 Months</option>
                <option value="18">18 Months</option>
                <option value="24">24 Months</option>
                <option value="36">36 Months</option>
              </select>
              <label for="tenure">Loan Tenure (in months)</label>
            </div>

            <!-- Interest Rate -->
            <div class="form-floating mb-3">
              <input type="number" class="form-control" id="interest" name="interest" placeholder="Interest Rate" value="10" step="0.1" oninput="calculateEMI()" required>
              <label for="interest">Interest Rate (Annual %)</label>
            </div>

            <!-- Purpose -->
            <div class="form-floating mb-3">
              <textarea class="form-control" id="purpose" name="purpose" placeholder="Purpose of Loan" style="height: 100px" required></textarea>
              <label for="purpose">Purpose of Loan</label>
            </div>

            <!-- Estimated EMI -->
            <div class="form-floating mb-4">
              <input type="text" class="form-control bg-light" id="emi" name="emi" readonly placeholder="Estimated EMI">
              <label for="emi">Estimated Monthly EMI (INR)</label>
            </div>

            <!-- Submit Button -->
            <div class="d-grid" align="center">
              <button type="submit" class="btn btn-primary btn-lg">Submit</button>
            </div>
          </form>

        </div>
      </div>
    </div>
  </div>
</div>

<!-- EMI Calculation Script -->
<script>
function calculateEMI() {
  const amount = parseFloat(document.getElementById("amount").value);
  const tenure = parseInt(document.getElementById("tenure").value);
  const annualInterest = parseFloat(document.getElementById("interest").value);

  if (isNaN(amount) || isNaN(tenure) || isNaN(annualInterest)) {
    document.getElementById("emi").value = '';
    return;
  }

  const monthlyInterest = annualInterest / 12 / 100;
  const emi = (amount * monthlyInterest * Math.pow(1 + monthlyInterest, tenure)) /
              (Math.pow(1 + monthlyInterest, tenure) - 1);

  document.getElementById("emi").value = emi ? emi.toFixed(2) : '';
}
</script>
<?php include_once("footer.php"); ?>
