<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class UserController extends CI_Controller {

    public function __construct() {
        parent::__construct();

        $this->load->model("UserModels");
    }

    public function UserList() {
         $this->load->model("UserModels");
        $var = $this->UserModels->get_users();
        //  echo "<pre>";print_r($var);
        $data['sum']=$var;
        // Loading the view and passing data
        $this->load->view('userList', $data);
    }
    public function Register() {
        // echo "<pre>";print_r($_REQUEST);//exit;
        $this->session->unset_userdata('user');
        $data = [
            'name'  => $this->input->post('name'),
            'email' => $this->input->post('email'),
            'phone' => $this->input->post('phone')
        ];

        $this->load->model('UserModels');  
        
        if($_REQUEST['Submit'] =="Login"){
            $check_email = $this->UserModels->get_users(['email' => $data['email']]);
            $check_phone = $this->UserModels->get_users(['phone' => $data['phone']]);
            // echo "<pre>";print_r($check_phone);exit;
             if (!empty($check_email) && !empty($check_phone) && $check_email[0]['id'] == $check_phone[0]['id']) {
                // ✅ Set session
                $this->session->set_userdata('user', $check_email[0]);
                redirect('index.php/Admin/LoanForm');
            } else {
                echo "<script>
                    alert('Your Email and Phone do not match or are not registered!');
                    window.location.href = '" . base_url('index.php/Admin/login') . "';
                </script>";
                exit;
            }
        }else{
            $check_email = $this->UserModels->get_users([
                'email' => $data['email']
            ]);

            if (!empty($check_email)) {
                echo "<script>
                    alert('Email already exists!');
                    window.location.href = '" . base_url('index.php/Admin/login') . "';
                </script>";
                exit;
            }
            $check_phone = $this->UserModels->get_users([
                'phone' => $data['phone']
            ]);

            if (!empty($check_phone)) {
             
                echo "<script>
                    alert('Phone number already exists!');
                    window.location.href = '" . base_url('index.php/Admin/login') . "';
                </script>";
                exit;
            }

            $reg_details = $this->UserModels->insert_user($data);     

            // echo "dddddddddd<pre>"; print_r($reg_details); // Debug print

            if ($reg_details['status']) {
                // Set session
                $this->session->set_userdata('user', $reg_details['user']);

            } 
            // echo "<pre>";
            // print_r($this->session->userdata());
            // exit;
            redirect('index.php/Admin/LoanForm');
        }
    }

    public function LoanApply() {
        // echo "<pre>";print_r($_REQUEST);
        $this->load->model('UserModels');             
        $user_details = $this->UserModels->get_users();
        $approval_person_details = $this->UserModels->get_approval_person();
        // echo "<pre>";print_r($approval_person_details);//exit;
        $approval_person = $approval_person_details[0]["approval_person"];
        $approval_array = json_decode($approval_person, true);

        $approval_details = [];

        $session_details=$this->session->userdata();
        // echo "<pre>";
        // print_r($session_details);//exit;
        $session_user_id=$session_details['user']["id"];
        foreach ($approval_array as $level => $approver) {
            $approval_details[$level] = [
                'user_id' => $approver['user_id'],
                'status' => 0,
                'remarks' => '',
                'updated_at' => null
            ];
        }
        // echo "=========".$session_user_id;exit;
        $data = [
            'amount'  => $this->input->post('amount'),
            'tenure_months' => $this->input->post('tenure'),
            'purpose' => $this->input->post('purpose'),
            'approve_person' => json_encode($approval_details),
            'user_id' =>$session_user_id
        ];
        // echo "<pre>";print_r($data);
        $this->load->model('UserModels');             
        $this->UserModels->insert_loan($data);     
        redirect('index.php/UserController/apply_loanList');
    }
    public function logout(){
        $this->session->sess_destroy();
        redirect("index.php/Admin/login");
    }
    public function create() {
        // echo "create data";exit;
        $this->load->view('UserCreate');
    }

    public function loanList(){
        $this->load->model("UserModels");
        //  $this->load->library('database');
        // echo "<pre>";
        // print_r($this->session->userdata());
       $loans = $this->UserModels->get_loan_details();
        // echo "<pre>";print_r($loans);exit;

        // Get current logged-in user ID from session
        $session_user = $this->session->userdata('user');
        $current_user_id = $session_user['id']; //isset($session_user['id']) ? str_pad($session_user['id']) : null;

        $my_approvals = [];

        if ($current_user_id) {
            foreach ($loans as $loan) {
                $approval_data = json_decode($loan['approve_person'], true);

                foreach ($approval_data as $level => $approver) {
                    // Check if current session user is approver at this level
                    if ($approver['user_id'] === $current_user_id && $approver['status'] == 0) {
                        // User is responsible and status is Pending
                        $loan['approval_level'] = $level;
                        $my_approvals[] = $loan;
                        break; // No need to check further levels for this loan
                    }
                }
            }
        }

        // ✅ Output or use $my_approvals
        // echo "<pre>Pending approvals for current user:\n";
        // print_r($my_approvals);//exit;
        $this->load->view('loanList', ['my_approvals' => $my_approvals]);

    }
     public function apply_loanList(){
        $this->load->model("UserModels");
        //  $this->load->library('database');
        // echo "<pre>";
        // print_r($this->session->userdata());exit;
        $session_user = $this->session->userdata('user');
        $current_user_id =isset($session_user['id']) ? $session_user['id']: null;
        $loans = $this->UserModels->get_loan_details($current_user_id);
        if(!empty($loans)){
            $my_approvals =$loans;
        }else{
            $my_approvals=array();
        }
        // echo "<pre>";print_r($my_approvals);
        // ✅ Output or use $my_approvals
        // echo "<pre>Pending approvals for current user:\n";
        // print_r($my_approvals);//exit;
        $this->load->view('loanList', ['my_approvals' => $my_approvals]);

    }
    public function approve(){
        // echo "<pre>";
        // print_r($this->input->get());
        $loans = $this->UserModels->get_loan_details();

        $ids=$this->input->get("id");
        $data = [
            'status'  => "1"
        ];

        $this->load->model('UserModels');             
        $reg_details = $this->UserModels->update_loan($ids,$data);     
        redirect('index.php/UserController/loanList');

        // echo "==========<pre>";print_r($_GET);
    }
    public function reject(){
        // echo "<pre>";
        // print_r($_GET);
         $ids=$this->input->get("id");
        $data = [
            'status'  => "2"
        ];

        $this->load->model('UserModels');             
        $reg_details = $this->UserModels->update_loan($ids,$data);    
        redirect('index.php/UserController/loanList');


    }
}

?>