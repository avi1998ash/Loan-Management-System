<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>LMS - Register</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: linear-gradient(to right, #4e73df, #224abe);
            font-family: 'Nunito', sans-serif;
        }
        .register-card {
            border: none;
            border-radius: 1rem;
            box-shadow: 0 1rem 2rem rgba(0,0,0,0.1);
        }
        .form-control-user {
            border-radius: 50px;
        }
        .btn-user {
            border-radius: 50px;
        }
    </style>
</head>
<body>

<div class="container py-5">
    <div class="row justify-content-center align-items-center min-vh-100">
        <div class="col-md-7 col-lg-6">
            <div class="card register-card p-4">
                <div class="card-body">
                    <h3 class="text-center mb-4 text-primary fw-bold">Create Your Account</h3>

                    <form action="<?php echo base_url('index.php/UserController/Register'); ?>" method="POST">

                        <div class="form-group mb-3">
                            <input type="text" name="name" class="form-control form-control-user" placeholder="Full Name" required>
                        </div>

                        <div class="form-group mb-3">
                            <input type="email" name="email" class="form-control form-control-user" placeholder="Email Address" required>
                        </div>

                        <div class="form-group mb-3">
                            <input type="text" name="phone" class="form-control form-control-user" placeholder="Phone Number" required>
                        </div>

                        <div class="form-group mb-4">
                            <input type="text" name="pan" class="form-control form-control-user" placeholder="PAN Number" required>
                        </div>

                        <div class="d-grid mb-2">
                            <input type="submit" name="Submit" class="btn btn-primary btn-user fw-bold" value="Register">
                        </div>

                        <div class="text-center">
                            <a href="<?php echo base_url('index.php/Admin/login'); ?>" class="text-decoration-none">Already have an account? <strong>Login</strong></a>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap 5 JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
