<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class HomeController extends CI_Controller{
    public function index()
	{
        $var['name'] = "testing in views";
		$this->load->view('HomePage',$var);
	}
}

?>